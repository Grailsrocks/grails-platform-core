package org.grails.plugin.platform.conventions

/**
 * Encapsulate a DSL command that is a regular method invocation
 *
 * something a, p
 */
class DSLCallCommand extends DSLCommand {
    List arguments
}