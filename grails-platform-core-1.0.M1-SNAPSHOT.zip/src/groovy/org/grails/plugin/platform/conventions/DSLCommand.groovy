package org.grails.plugin.platform.conventions

import org.slf4j.LoggerFactory

/**
 * Encapsulate a basic DSL comand
 */
class DSLCommand {
    String name
}