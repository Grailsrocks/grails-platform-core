modules = {
    'plugin.platformCore.tools' {
        resource url:[plugin:'platformCore', dir:'css', file:'platformTools.css']
    }
}